# 假设台账

默认条目为 `ASSUMPTION`。排序依据：爆炸半径 ÷ 验证成本。

| ID | 类型 | 内容 | 证据/来源 | 验证方式 | 验证成本 | 为假时爆炸半径 | 状态 |
|---|---|---|---|---|---|---|---|
| F-001 | FACT | 代表处范围是数据维度权限；idx 142 已人工纠正为数据权限。 | 业务方在 2026-07-31 的明确确认 | 已验证 | 已完成 | 高 | VALID |
| A-003 | ASSUMPTION | 数据维度绑定在具体角色实例下，而不是用户级独立维度。 | 当前目标 Schema 与权限业务惯例 | 获取真实权限 API 三条脱敏返回 | 中 | 极高：需重做权限数据模型和谓词 | OPEN |
| A-005 | ASSUMPTION | 真实权限 API 能映射 role_id/status/valid_to/scopes/data_freshness。 | 当前为构造样例，尚无真实返回 | 权限平台提供字段字典和三条返回 | 中 | 极高：接口适配和部分诊断重做 | OPEN |
| A-001 | ASSUMPTION | searchRevenue 页面在目标工单中可稳定映射到收入触发查询能力。 | 12/26 命中 searchRevenue；5 条 EBG S1 同质案例 | 对新增真实工单做 shadow 标注 | 低 | 中 | OPEN |
| A-002 | ASSUMPTION | EBG 查询角色标准名称为 `EISDP_Monitor RTS 业务监控人员RTS` 且角色逻辑唯一。 | 多条历史工单反复出现 | 角色 Owner 确认标准 Role ID 与名称 | 低 | 高：角色建议可能错误 | OPEN |
| A-004 | ASSUMPTION | 首轮仅支持 EBG 仍能产生足够真实 shadow 案例。 | 26 条中 EBG 明确 8 条 | 连续收集两周新工单 | 低 | 低：切换 CNBG 或扩展范围 | OPEN |
| A-006 | ASSUMPTION | `/v1/diagnose` 当前字段足以支持首个调用方。 | 尚无真实调用方确认 | 用 API 契约与前端/客服接入方走查 | 低 | 中：新增字段可加法兼容 | OPEN |
| A-007 | ASSUMPTION | 确定性规则足以覆盖首轮四类权限原因。 | 已知规则可形式化 | shadow 案例逐条对比人工结论 | 中 | 中：增加新的 reason code | OPEN |
| A-008 | ASSUMPTION | PoC 期间配置文件足以承载单策略、固定 Fixture 和评测集。 | 本轮不验证在线知识治理 | 出现并发更新或多租户要求时复审 | 低 | 低 | OPEN |
| A-009 | ASSUMPTION | 授权数据超过 24 小时可视为过旧并强制升级。 | 当前无权限平台 SLA | 向权限平台确认 freshness SLA | 低 | 中：过严会增加转人工，过松会错判 | OPEN |
| A-010 | ASSUMPTION | 审批完成后 20 分钟内属于正常传播窗口。 | 历史工单文本 | Owner/平台确认生效 SLA | 低 | 中 | OPEN |
| C-001 | CONSTRAINT | PoC 不自动申请、审批或修改权限。 | POC 方案与安全边界 | 外部约束，无需验证 | - | - | ACTIVE |
| C-002 | CONSTRAINT | Function ID、Role ID、标准维度枚举暂未由权威系统提供。 | 上游依赖现状 | 获取真实契约 | 中 | 高 | ACTIVE |
