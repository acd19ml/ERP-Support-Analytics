from fastapi.testclient import TestClient

from metaerp_poc.api import app


def test_diagnose_contract():
    client = TestClient(app)
    response = client.post(
        "/v1/diagnose",
        json={
            "schema_version": "1.0",
            "conversation_id": "contract-001",
            "user_id": "U_POC_MISSING_ROLE",
            "message": "searchRevenue 查不到江苏代表处 EBG 合同数据",
            "page_url": "https://one.erp.huawei.com/#/externalApp@hcc_rts_server/searchRevenue",
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert body["schema_version"] == "1.0"
    assert body["diagnosis"]["cause_code"] == "MISSING_ROLE"
    assert body["diagnosis"]["recommended_action"]["role_id"] == "role-poc-rts-ebg-monitor"
    assert body["metadata"]["policy_version"] == "1.0.0"


def test_unknown_user_escalates_without_guessing():
    client = TestClient(app)
    response = client.post(
        "/v1/diagnose",
        json={
            "schema_version": "1.0",
            "conversation_id": "contract-002",
            "user_id": "UNKNOWN_USER",
            "message": "收入触发查询查不到江苏代表处 EBG 合同",
        },
    )
    body = response.json()
    assert body["status"] == "ESCALATED"
    assert body["diagnosis"] is None
    assert body["metadata"]["escalation_reason"] == "ENTITLEMENT_TOOL_UNAVAILABLE"
