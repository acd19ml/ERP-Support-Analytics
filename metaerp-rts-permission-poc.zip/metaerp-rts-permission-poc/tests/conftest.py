from datetime import datetime

import pytest


@pytest.fixture
def frozen_now() -> datetime:
    return datetime.fromisoformat("2026-07-31T08:05:00+00:00")
