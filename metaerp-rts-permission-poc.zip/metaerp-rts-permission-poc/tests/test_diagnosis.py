import pytest

from metaerp_poc.config import load_policy
from metaerp_poc.diagnosis import PermissionDiagnoser
from metaerp_poc.models import TargetDimension
from metaerp_poc.repositories import FixtureEntitlementRepository


@pytest.mark.parametrize(
    ("user_id", "cause", "decision"),
    [
        ("U_POC_MISSING_ROLE", "MISSING_ROLE", "DENY"),
        ("U_POC_MISSING_SCOPE", "MISSING_DATA_SCOPE", "DENY"),
        ("U_POC_EXPIRED_ROLE", "EXPIRED_ROLE", "DENY"),
        ("U_POC_EXPIRED_SCOPE", "EXPIRED_DATA_SCOPE", "DENY"),
        ("U_POC_PENDING", "PENDING_ACTIVATION", "DENY"),
        ("U_POC_SATISFIED", "PERMISSION_SATISFIED_BUT_NO_DATA", "UNKNOWN"),
        ("U_POC_STALE", "ENTITLEMENT_DATA_STALE", "UNKNOWN"),
        ("U_POC_CONFIDENTIAL", "CONFIDENTIAL_SCOPE", "UNKNOWN"),
    ],
)
def test_deterministic_branches(user_id, cause, decision, frozen_now):
    policy = load_policy()
    snapshot = FixtureEntitlementRepository().get_user_snapshot(user_id)
    result = PermissionDiagnoser().diagnose(
        policy=policy,
        snapshot=snapshot,
        target=TargetDimension(
            dimension_type="REP_OFFICE",
            dimension_code="rep-poc-jiangsu-cn",
            dimension_name="Jiangsu Rep Office, CN",
            bg="EBG",
        ),
        now=frozen_now,
    )
    assert result.cause_code == cause
    assert result.decision == decision


def test_scope_from_unrelated_role_is_not_merged(frozen_now):
    """A target scope under an unrelated role must not satisfy RTS access."""
    policy = load_policy()
    snapshot = FixtureEntitlementRepository().get_user_snapshot("U_POC_MISSING_ROLE")
    result = PermissionDiagnoser().diagnose(
        policy=policy,
        snapshot=snapshot,
        target=TargetDimension(
            dimension_type="REP_OFFICE",
            dimension_code="rep-poc-jiangsu-cn",
            dimension_name="Jiangsu Rep Office, CN",
            bg="EBG",
        ),
        now=frozen_now,
    )
    assert result.cause_code == "MISSING_ROLE"
