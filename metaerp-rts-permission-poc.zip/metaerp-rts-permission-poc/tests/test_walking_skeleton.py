from metaerp_poc.models import DiagnoseRequest
from metaerp_poc.service import DiagnosisService


def test_walking_skeleton_stays_green(frozen_now):
    response = DiagnosisService().diagnose(
        DiagnoseRequest(
            conversation_id="conv-walking-001",
            user_id="U_POC_MISSING_SCOPE",
            message="我在收入触发查询里查不到江苏代表处的EBG合同",
            page_url="https://one.erp.huawei.com/#/externalApp@hcc_rts_server/searchRevenue",
        ),
        now=frozen_now,
    )
    assert response.status == "DIAGNOSED"
    assert response.understanding.requested_action == "QUERY"
    assert response.understanding.target_dimension.dimension_code == "rep-poc-jiangsu-cn"
    assert response.diagnosis is not None
    assert response.diagnosis.cause_code == "MISSING_DATA_SCOPE"
    assert "代表处数据范围" in response.response_text
    assert [step.action for step in response.trace] == [
        "UNDERSTAND_REQUEST",
        "LOAD_POLICY",
        "GET_ENTITLEMENTS",
        "DETERMINISTIC_DIAGNOSIS",
    ]
