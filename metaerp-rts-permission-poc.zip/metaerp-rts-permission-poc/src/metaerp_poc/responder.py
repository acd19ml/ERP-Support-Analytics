from __future__ import annotations

from .models import Diagnosis, Understanding


def render_response(understanding: Understanding, diagnosis: Diagnosis) -> str:
    action = diagnosis.recommended_action
    target_name = understanding.target_dimension.dimension_name or "目标代表处"

    if diagnosis.cause_code == "MISSING_ROLE" and action:
        return (
            f"当前已定位为 RTS 收入触发查询（EBG）。权限检查显示您尚未拥有查询角色“{action.role_name}”。"
            f"请通过 iAuth 申请该角色：{action.application_entry}。申请生效后，再查询 {target_name} 的合同数据。"
        )
    if diagnosis.cause_code == "MISSING_DATA_SCOPE" and action:
        return (
            f"您已具备 RTS EBG 查询角色，但该角色实例下未包含“{target_name}”代表处数据范围。"
            f"请在 iAuth 为角色“{action.role_name}”补充该代表处数据权限：{action.application_entry}。"
        )
    if diagnosis.cause_code == "EXPIRED_ROLE" and action:
        return f"RTS EBG 查询角色“{action.role_name}”已失效，请在 iAuth 续期或重新申请：{action.application_entry}。"
    if diagnosis.cause_code == "EXPIRED_DATA_SCOPE" and action:
        return (
            f"RTS EBG 查询角色仍有效，但“{target_name}”代表处数据权限已失效。"
            f"请续期该数据范围：{action.application_entry}。"
        )
    if diagnosis.cause_code == "PENDING_ACTIVATION" and action:
        return f"相关权限正在生效中，建议等待约 {action.wait_minutes or 0} 分钟后重新查询。若超过预计时间仍未生效，将转人工核查。"
    if diagnosis.cause_code == "PERMISSION_SATISFIED_BUT_NO_DATA":
        return (
            "已核实 RTS EBG 查询角色和目标代表处数据权限均满足，因此不建议重复申请权限。"
            "当前更可能是业务数据或系统问题，已生成权限诊断摘要并转交人工支持。"
        )
    return f"当前无法形成有权威证据支持的权限结论（{diagnosis.cause_code}），已转人工处理。"
