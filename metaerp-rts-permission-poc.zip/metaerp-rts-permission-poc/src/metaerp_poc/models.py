from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class DiagnoseRequest(StrictModel):
    # BOUNDARY(D-004): Public request contract; evolve additively only.
    schema_version: str = "1.0"
    conversation_id: str = Field(min_length=1)
    user_id: str = Field(min_length=1)
    message: str = Field(min_length=1)
    page_url: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Evidence(StrictModel):
    kind: str
    value: str


class TargetDimension(StrictModel):
    dimension_type: str | None = None
    dimension_code: str | None = None
    dimension_name: str | None = None
    bg: str | None = None


class Understanding(StrictModel):
    schema_version: str = "1.0"
    local_capability_id: str | None = None
    page_route: str | None = None
    resource_type: str | None = None
    requested_action: str | None = None
    symptom: str | None = None
    target_bg: str | None = None
    target_dimension: TargetDimension = Field(default_factory=TargetDimension)
    user_hypothesis: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    ambiguities: list[str] = Field(default_factory=list)
    evidence: list[Evidence] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ScopeGrant(StrictModel):
    schema_version: str = "1.0"
    dimension_type: str
    dimension_code: str
    dimension_name: str
    bg: str | None = None
    status: str
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class RoleGrant(StrictModel):
    schema_version: str = "1.0"
    role_id: str
    role_name: str
    status: str
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    status_updated_at: datetime | None = None
    scopes: list[ScopeGrant] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class EntitlementSnapshot(StrictModel):
    # BOUNDARY(D-004): Adapter target for the future real entitlement API.
    schema_version: str = "1.0"
    snapshot_id: str
    user_id: str
    organization_bg: str | None = None
    grants: list[RoleGrant] = Field(default_factory=list)
    data_freshness: datetime
    limitations: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class RoleRequirement(StrictModel):
    role_id: str
    role_name: str
    status_required: str


class ScopeRequirement(StrictModel):
    dimension_type: str
    status_required: str
    binding: str
    operator: str


class AccessPolicy(StrictModel):
    # BOUNDARY(D-004): Policy contract; official IDs may be added without changing semantics.
    schema_version: str = "1.0"
    policy_id: str
    policy_version: str
    status: str
    local_capability_id: str
    page_route: str
    resource_type: str
    action: str
    target_bg: str
    role: RoleRequirement
    scope: ScopeRequirement
    expected_propagation_minutes: int
    application_entry: str
    cross_bg_allowed: bool
    confidential_scope_allowed: bool
    metadata: dict[str, Any] = Field(default_factory=dict)


class CheckResult(StrictModel):
    check_id: str
    result: str
    evidence: list[str] = Field(default_factory=list)


class RecommendedAction(StrictModel):
    action_code: str
    role_id: str | None = None
    role_name: str | None = None
    dimension_type: str | None = None
    dimension_code: str | None = None
    dimension_name: str | None = None
    application_entry: str | None = None
    wait_minutes: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Diagnosis(StrictModel):
    # BOUNDARY(D-004): Consumers may automate on decision/cause_code; never reuse meanings.
    schema_version: str = "1.0"
    decision: str
    cause_code: str
    confidence_mode: str = "DETERMINISTIC"
    policy_id: str | None = None
    policy_version: str | None = None
    entitlement_snapshot_id: str | None = None
    checks: list[CheckResult] = Field(default_factory=list)
    recommended_action: RecommendedAction | None = None
    mandatory_escalation: bool = False
    escalation_reason: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class TraceStep(StrictModel):
    step: int
    action: str
    output: str
    evidence: list[str] = Field(default_factory=list)


class DiagnoseResponse(StrictModel):
    # BOUNDARY(D-004): Public response contract; only additive evolution in PoC.
    schema_version: str = "1.0"
    conversation_id: str
    status: str
    understanding: Understanding
    diagnosis: Diagnosis | None = None
    response_text: str
    trace: list[TraceStep] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
