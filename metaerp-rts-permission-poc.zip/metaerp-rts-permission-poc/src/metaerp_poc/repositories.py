from __future__ import annotations

import json
from pathlib import Path
from typing import Protocol

from .config import ROOT, load_policy
from .models import AccessPolicy, EntitlementSnapshot


class PolicyRepository(Protocol):
    def get_for_capability(self, local_capability_id: str) -> AccessPolicy: ...


class EntitlementRepository(Protocol):
    def get_user_snapshot(self, user_id: str) -> EntitlementSnapshot: ...


class FilePolicyRepository:
    def get_for_capability(self, local_capability_id: str) -> AccessPolicy:
        policy = load_policy()
        if policy.local_capability_id != local_capability_id:
            raise KeyError(f"No policy for capability: {local_capability_id}")
        return policy


class FixtureEntitlementRepository:
    # POC-ONLY(D-003): Replace with a read-only real API adapter after contract confirmation.
    def __init__(self, fixture_dir: Path | None = None) -> None:
        self.fixture_dir = fixture_dir or ROOT / "fixtures" / "entitlements"

    def get_user_snapshot(self, user_id: str) -> EntitlementSnapshot:
        path = self.fixture_dir / f"{user_id}.json"
        if not path.exists():
            raise KeyError(f"No entitlement fixture for user: {user_id}")
        with path.open("r", encoding="utf-8") as fh:
            return EntitlementSnapshot.model_validate(json.load(fh))
