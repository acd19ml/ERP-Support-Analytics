from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .models import AccessPolicy, RoleRequirement, ScopeRequirement

ROOT = Path(__file__).resolve().parents[2]


def load_yaml(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def load_policy() -> AccessPolicy:
    raw = load_yaml(ROOT / "config" / "policy.rts.search_revenue.ebg.v1.yaml")
    capability = raw["capability"]
    entitlement = raw["required_entitlement"]
    activation = raw["activation"]
    risk = raw["risk"]
    return AccessPolicy(
        schema_version=raw["schema_version"],
        policy_id=raw["policy_id"],
        policy_version=raw["policy_version"],
        status=raw["status"],
        local_capability_id=capability["local_capability_id"],
        page_route=capability["page_route"],
        resource_type=capability["resource_type"],
        action=capability["action"],
        target_bg=raw["target_conditions"]["bg"],
        role=RoleRequirement(**entitlement["role"]),
        scope=ScopeRequirement(**entitlement["data_scope"]),
        expected_propagation_minutes=activation["expected_propagation_minutes"],
        application_entry=activation["application_entry"],
        cross_bg_allowed=risk["cross_bg_allowed"],
        confidential_scope_allowed=risk["confidential_scope_allowed"],
        metadata={"governance": raw.get("governance", {}), **raw.get("metadata", {})},
    )
