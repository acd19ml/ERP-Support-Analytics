from __future__ import annotations

from fastapi import FastAPI

from .models import DiagnoseRequest, DiagnoseResponse
from .service import DiagnosisService

app = FastAPI(title="MetaERP RTS Permission PoC", version="0.1.0")
service = DiagnosisService()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "schema_version": "1.0"}


@app.post("/v1/diagnose", response_model=DiagnoseResponse)
def diagnose(request: DiagnoseRequest) -> DiagnoseResponse:
    return service.diagnose(request)
