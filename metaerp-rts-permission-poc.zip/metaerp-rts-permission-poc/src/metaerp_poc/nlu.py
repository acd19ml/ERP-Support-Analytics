from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from .config import ROOT, load_yaml
from .models import DiagnoseRequest, Evidence, TargetDimension, Understanding


class NluProvider(Protocol):
    def understand(self, request: DiagnoseRequest) -> Understanding: ...


@dataclass(frozen=True)
class DimensionAlias:
    code: str
    canonical_name: str
    aliases: tuple[str, ...]
    bg: str


class RuleBasedNluProvider:
    # POC-ONLY(D-005): This closes the skeleton; replace behind NluProvider with a pinned LLM later.
    # UNMEASURED(A-006): Accuracy claims are invalid until eval/shadow results are recorded.
    def __init__(self) -> None:
        functions = load_yaml(ROOT / "config" / "function_aliases.yaml")
        self.capability = functions["capabilities"][0]
        dimensions = load_yaml(ROOT / "config" / "dimension_aliases.yaml")
        self.dimensions = [
            DimensionAlias(
                code=item["code"],
                canonical_name=item["canonical_name"],
                aliases=tuple(item["aliases"]),
                bg=item["bg"],
            )
            for item in dimensions["aliases"]
        ]

    def understand(self, request: DiagnoseRequest) -> Understanding:
        haystack = f"{request.message} {request.page_url or ''}"
        evidence: list[Evidence] = []

        page_route = None
        capability_id = None
        resource_type = None
        if self.capability["page_route"] in haystack or any(
            alias.lower() in haystack.lower() for alias in self.capability["aliases"]
        ):
            page_route = self.capability["page_route"]
            capability_id = self.capability["local_capability_id"]
            resource_type = self.capability["resource_type"]
            evidence.append(Evidence(kind="FUNCTION_MATCH", value=page_route))

        query_terms = ("查询", "查", "查不到", "找不到", "搜索", "查找", "看不到", "没有数据", "没数据")
        requested_action = "QUERY" if any(term in haystack for term in query_terms) else None
        if requested_action:
            evidence.append(Evidence(kind="ACTION_TEXT", value="QUERY"))

        symptom = "NO_DATA" if any(term in haystack for term in ("查不到", "找不到", "看不到", "没有数据", "没数据")) else None
        target_bg = "EBG" if "EBG" in haystack.upper() or "数字能源" in haystack else None
        if target_bg:
            evidence.append(Evidence(kind="BG_TEXT", value=target_bg))

        dimension = TargetDimension(dimension_type="REP_OFFICE")
        for item in self.dimensions:
            matched = next((alias for alias in item.aliases if alias.lower() in haystack.lower()), None)
            if matched:
                dimension = TargetDimension(
                    dimension_type="REP_OFFICE",
                    dimension_code=item.code,
                    dimension_name=item.canonical_name,
                    bg=item.bg,
                )
                evidence.append(Evidence(kind="DIMENSION_ALIAS", value=matched))
                break

        user_hypothesis = "MISSING_PERMISSION" if "权限" in request.message else None
        missing: list[str] = []
        if not page_route:
            missing.append("function_locator")
        if not requested_action:
            missing.append("requested_action")
        if not target_bg:
            missing.append("target_bg")
        if not dimension.dimension_code:
            missing.append("target_dimension_code")

        return Understanding(
            local_capability_id=capability_id,
            page_route=page_route,
            resource_type=resource_type,
            requested_action=requested_action,
            symptom=symptom,
            target_bg=target_bg,
            target_dimension=dimension,
            user_hypothesis=user_hypothesis,
            missing_fields=missing,
            evidence=evidence,
            metadata={"prompt_version": "nlu-v1", "provider": "rule-based"},
        )
