from __future__ import annotations

from datetime import datetime, timezone

from .models import (
    AccessPolicy,
    CheckResult,
    Diagnosis,
    EntitlementSnapshot,
    RecommendedAction,
    TargetDimension,
)


class PermissionDiagnoser:
    def __init__(self, freshness_hours: int = 24) -> None:
        # ASSUMPTION(A-009): 24h is a temporary freshness threshold until platform SLA is known.
        self.freshness_hours = freshness_hours

    def diagnose(
        self,
        *,
        policy: AccessPolicy,
        snapshot: EntitlementSnapshot,
        target: TargetDimension,
        now: datetime | None = None,
    ) -> Diagnosis:
        now = now or datetime.now(timezone.utc)
        checks: list[CheckResult] = []

        if "CONFIDENTIAL_SCOPE" in snapshot.limitations or "TARGET_CONFIDENTIAL" in snapshot.limitations:
            checks.append(CheckResult(check_id="CHECK_CONFIDENTIAL", result="UNKNOWN", evidence=snapshot.limitations))
            return self._escalate(policy, snapshot, checks, "CONFIDENTIAL_SCOPE")

        age_hours = (now - snapshot.data_freshness).total_seconds() / 3600
        if age_hours > self.freshness_hours:
            checks.append(
                CheckResult(
                    check_id="CHECK_DATA_FRESHNESS",
                    result="UNKNOWN",
                    evidence=[f"age_hours={age_hours:.2f}", f"threshold={self.freshness_hours}"],
                )
            )
            return self._escalate(policy, snapshot, checks, "ENTITLEMENT_DATA_STALE")
        checks.append(CheckResult(check_id="CHECK_DATA_FRESHNESS", result="PASS", evidence=[snapshot.data_freshness.isoformat()]))

        if policy.status != "POC_APPROVED":
            checks.append(CheckResult(check_id="CHECK_POLICY_STATUS", result="UNKNOWN", evidence=[policy.status]))
            return self._escalate(policy, snapshot, checks, "POLICY_NOT_APPROVED")
        checks.append(CheckResult(check_id="CHECK_POLICY_STATUS", result="PASS", evidence=[policy.status]))

        role_instances = [grant for grant in snapshot.grants if grant.role_id == policy.role.role_id]
        if not role_instances:
            checks.append(CheckResult(check_id="CHECK_REQUIRED_ROLE", result="FAIL", evidence=[policy.role.role_id]))
            return self._deny(
                policy,
                snapshot,
                checks,
                cause="MISSING_ROLE",
                action=RecommendedAction(
                    action_code="APPLY_ROLE",
                    role_id=policy.role.role_id,
                    role_name=policy.role.role_name,
                    application_entry=policy.application_entry,
                ),
            )
        checks.append(CheckResult(check_id="CHECK_REQUIRED_ROLE", result="PASS", evidence=[g.role_id for g in role_instances]))

        active_roles = [g for g in role_instances if self._is_active(g.status, g.valid_to, now)]
        pending_roles = [g for g in role_instances if g.status == "PENDING"]
        if not active_roles and pending_roles:
            pending = pending_roles[0]
            elapsed_minutes = None
            if pending.status_updated_at:
                elapsed_minutes = int((now - pending.status_updated_at).total_seconds() / 60)
            if elapsed_minutes is not None and elapsed_minutes <= policy.expected_propagation_minutes:
                checks.append(CheckResult(check_id="CHECK_ROLE_ACTIVATION", result="PENDING", evidence=[f"elapsed_minutes={elapsed_minutes}"]))
                return self._deny(
                    policy,
                    snapshot,
                    checks,
                    cause="PENDING_ACTIVATION",
                    action=RecommendedAction(
                        action_code="WAIT_FOR_ACTIVATION",
                        role_id=policy.role.role_id,
                        role_name=policy.role.role_name,
                        wait_minutes=max(policy.expected_propagation_minutes - elapsed_minutes, 0),
                    ),
                )
            checks.append(CheckResult(check_id="CHECK_ROLE_ACTIVATION", result="UNKNOWN", evidence=["pending_overdue_or_time_unknown"]))
            return self._escalate(policy, snapshot, checks, "ACTIVATION_OVERDUE")

        if not active_roles:
            checks.append(CheckResult(check_id="CHECK_ROLE_VALIDITY", result="FAIL", evidence=[g.status for g in role_instances]))
            return self._deny(
                policy,
                snapshot,
                checks,
                cause="EXPIRED_ROLE",
                action=RecommendedAction(
                    action_code="RENEW_PERMISSION",
                    role_id=policy.role.role_id,
                    role_name=policy.role.role_name,
                    application_entry=policy.application_entry,
                ),
            )
        checks.append(CheckResult(check_id="CHECK_ROLE_VALIDITY", result="PASS", evidence=[g.role_id for g in active_roles]))

        # ASSUMPTION(A-003): Scope is checked only under matching role instances.
        matching_scopes = [
            scope
            for role in active_roles
            for scope in role.scopes
            if scope.dimension_type == policy.scope.dimension_type
            and scope.dimension_code == target.dimension_code
        ]
        if not matching_scopes:
            checks.append(
                CheckResult(
                    check_id="CHECK_ROLE_INSTANCE_SCOPE_COVERAGE",
                    result="FAIL",
                    evidence=[target.dimension_code or "missing-target-code"],
                )
            )
            return self._deny(
                policy,
                snapshot,
                checks,
                cause="MISSING_DATA_SCOPE",
                action=RecommendedAction(
                    action_code="APPLY_DATA_SCOPE",
                    role_id=policy.role.role_id,
                    role_name=policy.role.role_name,
                    dimension_type=target.dimension_type,
                    dimension_code=target.dimension_code,
                    dimension_name=target.dimension_name,
                    application_entry=policy.application_entry,
                ),
            )

        active_scopes = [scope for scope in matching_scopes if self._is_active(scope.status, scope.valid_to, now)]
        if not active_scopes:
            checks.append(CheckResult(check_id="CHECK_SCOPE_VALIDITY", result="FAIL", evidence=[s.status for s in matching_scopes]))
            return self._deny(
                policy,
                snapshot,
                checks,
                cause="EXPIRED_DATA_SCOPE",
                action=RecommendedAction(
                    action_code="RENEW_DATA_SCOPE",
                    role_id=policy.role.role_id,
                    role_name=policy.role.role_name,
                    dimension_type=target.dimension_type,
                    dimension_code=target.dimension_code,
                    dimension_name=target.dimension_name,
                    application_entry=policy.application_entry,
                ),
            )

        checks.append(CheckResult(check_id="CHECK_ROLE_INSTANCE_SCOPE_COVERAGE", result="PASS", evidence=[s.dimension_code for s in active_scopes]))
        return self._escalate(policy, snapshot, checks, "PERMISSION_SATISFIED_BUT_NO_DATA")

    @staticmethod
    def _is_active(status: str, valid_to: datetime | None, now: datetime) -> bool:
        return status == "ACTIVE" and (valid_to is None or valid_to >= now)

    @staticmethod
    def _deny(
        policy: AccessPolicy,
        snapshot: EntitlementSnapshot,
        checks: list[CheckResult],
        *,
        cause: str,
        action: RecommendedAction,
    ) -> Diagnosis:
        return Diagnosis(
            decision="DENY",
            cause_code=cause,
            policy_id=policy.policy_id,
            policy_version=policy.policy_version,
            entitlement_snapshot_id=snapshot.snapshot_id,
            checks=checks,
            recommended_action=action,
        )

    @staticmethod
    def _escalate(
        policy: AccessPolicy,
        snapshot: EntitlementSnapshot,
        checks: list[CheckResult],
        cause: str,
    ) -> Diagnosis:
        return Diagnosis(
            decision="UNKNOWN",
            cause_code=cause,
            policy_id=policy.policy_id,
            policy_version=policy.policy_version,
            entitlement_snapshot_id=snapshot.snapshot_id,
            checks=checks,
            recommended_action=RecommendedAction(action_code="ESCALATE"),
            mandatory_escalation=True,
            escalation_reason=cause,
        )
