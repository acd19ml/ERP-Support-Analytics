from __future__ import annotations

import argparse
import json

from .models import DiagnoseRequest
from .service import DiagnosisService


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--user-id", required=True)
    parser.add_argument("--message", required=True)
    parser.add_argument("--page-url")
    args = parser.parse_args()

    response = DiagnosisService().diagnose(
        DiagnoseRequest(
            conversation_id="cli-demo",
            user_id=args.user_id,
            message=args.message,
            page_url=args.page_url,
        )
    )
    print(json.dumps(response.model_dump(mode="json"), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
