from __future__ import annotations

from datetime import datetime, timezone

from .diagnosis import PermissionDiagnoser
from .models import DiagnoseRequest, DiagnoseResponse, TraceStep, Understanding
from .nlu import NluProvider, RuleBasedNluProvider
from .repositories import (
    EntitlementRepository,
    FilePolicyRepository,
    FixtureEntitlementRepository,
    PolicyRepository,
)
from .responder import render_response


class DiagnosisService:
    def __init__(
        self,
        *,
        nlu: NluProvider | None = None,
        policies: PolicyRepository | None = None,
        entitlements: EntitlementRepository | None = None,
        diagnoser: PermissionDiagnoser | None = None,
    ) -> None:
        self.nlu = nlu or RuleBasedNluProvider()
        self.policies = policies or FilePolicyRepository()
        self.entitlements = entitlements or FixtureEntitlementRepository()
        self.diagnoser = diagnoser or PermissionDiagnoser()

    def diagnose(self, request: DiagnoseRequest, now: datetime | None = None) -> DiagnoseResponse:
        now = now or datetime.now(timezone.utc)
        trace: list[TraceStep] = []
        understanding = self.nlu.understand(request)
        trace.append(
            TraceStep(
                step=1,
                action="UNDERSTAND_REQUEST",
                output=understanding.local_capability_id or "UNRESOLVED",
                evidence=[f"{item.kind}:{item.value}" for item in understanding.evidence],
            )
        )

        scope_response = self._scope_gate(request, understanding, trace)
        if scope_response:
            return scope_response

        assert understanding.local_capability_id
        policy = self.policies.get_for_capability(understanding.local_capability_id)
        trace.append(TraceStep(step=2, action="LOAD_POLICY", output=policy.policy_id, evidence=[policy.policy_version]))

        try:
            snapshot = self.entitlements.get_user_snapshot(request.user_id)
        except KeyError:
            trace.append(TraceStep(step=3, action="GET_ENTITLEMENTS", output="UNAVAILABLE"))
            return DiagnoseResponse(
                conversation_id=request.conversation_id,
                status="ESCALATED",
                understanding=understanding,
                response_text="当前无法取得用户真实权限状态，不能给出确定性权限建议，已转人工处理。",
                trace=trace,
                metadata={"escalation_reason": "ENTITLEMENT_TOOL_UNAVAILABLE"},
            )
        trace.append(TraceStep(step=3, action="GET_ENTITLEMENTS", output=snapshot.snapshot_id, evidence=[snapshot.data_freshness.isoformat()]))

        diagnosis = self.diagnoser.diagnose(
            policy=policy,
            snapshot=snapshot,
            target=understanding.target_dimension,
            now=now,
        )
        trace.append(
            TraceStep(
                step=4,
                action="DETERMINISTIC_DIAGNOSIS",
                output=diagnosis.cause_code,
                evidence=[f"{c.check_id}:{c.result}" for c in diagnosis.checks],
            )
        )

        return DiagnoseResponse(
            conversation_id=request.conversation_id,
            status="ESCALATED" if diagnosis.mandatory_escalation else "DIAGNOSED",
            understanding=understanding,
            diagnosis=diagnosis,
            response_text=render_response(understanding, diagnosis),
            trace=trace,
            metadata={
                "policy_version": policy.policy_version,
                "entitlement_data_freshness": snapshot.data_freshness.isoformat(),
            },
        )

    @staticmethod
    def _scope_gate(
        request: DiagnoseRequest,
        understanding: Understanding,
        trace: list[TraceStep],
    ) -> DiagnoseResponse | None:
        if understanding.local_capability_id is None or understanding.requested_action != "QUERY":
            trace.append(TraceStep(step=2, action="SCOPE_GATE", output="OUT_OF_SCOPE"))
            return DiagnoseResponse(
                conversation_id=request.conversation_id,
                status="OUT_OF_SCOPE",
                understanding=understanding,
                response_text="当前 PoC 仅支持 RTS searchRevenue 页面的 EBG 收入触发查询问题。",
                trace=trace,
            )

        if understanding.target_bg is None or understanding.target_dimension.dimension_code is None:
            missing = ", ".join(understanding.missing_fields)
            trace.append(TraceStep(step=2, action="SCOPE_GATE", output="NEED_CONTEXT", evidence=understanding.missing_fields))
            return DiagnoseResponse(
                conversation_id=request.conversation_id,
                status="NEED_CONTEXT",
                understanding=understanding,
                response_text=f"还需要确认目标合同所属 BG 和代表处。当前缺少：{missing}。",
                trace=trace,
            )

        if understanding.target_bg != "EBG" or understanding.target_dimension.bg != "EBG":
            trace.append(TraceStep(step=2, action="SCOPE_GATE", output="OTHER_BG"))
            return DiagnoseResponse(
                conversation_id=request.conversation_id,
                status="OUT_OF_SCOPE",
                understanding=understanding,
                response_text="当前 PoC 仅支持 EBG，其他 BG 或跨 BG 场景必须转人工。",
                trace=trace,
            )
        return None
