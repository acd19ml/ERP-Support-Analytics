from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src"
DOCS = "\n".join(
    path.read_text(encoding="utf-8")
    for path in [ROOT / "docs" / "decision-log.md", ROOT / "docs" / "assumption-ledger.md"]
)
PATTERN = re.compile(r"(?:ASSUMPTION|POC-ONLY|BOUNDARY|UNMEASURED)\(([A-Z]-\d{3})\)")
markers: list[tuple[Path, str]] = []
for path in SOURCE.rglob("*.py"):
    for marker_id in PATTERN.findall(path.read_text(encoding="utf-8")):
        markers.append((path, marker_id))

missing = [(path, marker_id) for path, marker_id in markers if marker_id not in DOCS]
if missing:
    for path, marker_id in missing:
        print(f"Missing ledger reference: {marker_id} in {path.relative_to(ROOT)}")
    raise SystemExit(1)

counts: dict[str, int] = {}
for _, marker_id in markers:
    counts[marker_id] = counts.get(marker_id, 0) + 1
print(f"risk_markers={len(markers)} unique_ids={len(counts)}")
for marker_id, count in sorted(counts.items()):
    print(f"{marker_id}: {count}")
