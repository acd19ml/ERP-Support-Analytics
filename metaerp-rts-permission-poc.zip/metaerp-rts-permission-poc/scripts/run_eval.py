from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from metaerp_poc.models import DiagnoseRequest
from metaerp_poc.service import DiagnosisService

ROOT = Path(__file__).resolve().parents[1]
DATASET = ROOT / "evals" / "dataset-v1.jsonl"
NOW = datetime.fromisoformat("2026-07-31T08:05:00+00:00")
service = DiagnosisService()

count = 0
failures: list[str] = []
for line in DATASET.read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    case = json.loads(line)
    response = service.diagnose(
        DiagnoseRequest(
            conversation_id=case["case_id"],
            user_id=case["user_id"],
            message=case["message"],
            page_url=case.get("page_url"),
        ),
        now=NOW,
    )
    count += 1
    actual_cause = response.diagnosis.cause_code if response.diagnosis else None
    checks = {
        "status": response.status,
        "cause": actual_cause,
        "action": response.understanding.requested_action,
        "dimension": response.understanding.target_dimension.dimension_code,
    }
    for key, expected in case["expected"].items():
        if checks[key] != expected:
            failures.append(f"{case['case_id']} {key}: expected={expected!r}, actual={checks[key]!r}")

if failures:
    print("\n".join(failures))
    raise SystemExit(1)
print(f"eval_passed={count} dataset_version=v1 prompt_version=nlu-v1 model_version=rule-based")
