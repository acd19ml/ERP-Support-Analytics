# MetaERP RTS 权限诊断 PoC

首条常绿路径：

```text
用户问题 → 结构化理解 → 功能/范围校验 → Fixture 权限查询
→ 确定性诊断 → 用户答复/转人工 → 决策轨迹
```

当前冻结范围：`searchRevenue × QUERY × EBG × REP_OFFICE × NO_DATA`。
代表处范围按已确认信息建模为**角色实例下的数据维度权限**。历史工单 `idx=142` 已人工纠正为数据权限问题。

## 运行

```bash
make demo       # 跑一条端到端样例
make test       # 契约与规则测试
make eval       # 固定评测集
make ci         # 风险标记 + 测试 + 评测
make dev        # 启动 HTTP API
```

HTTP 示例：

```bash
curl -X POST http://localhost:8000/v1/diagnose \
  -H 'content-type: application/json' \
  -d '{
    "schema_version":"1.0",
    "conversation_id":"conv-demo-001",
    "user_id":"U_POC_MISSING_SCOPE",
    "message":"我在收入触发查询里查不到江苏代表处的EBG合同",
    "page_url":"https://one.erp.huawei.com/#/externalApp@hcc_rts_server/searchRevenue"
  }'
```

## 当前边界

- 策略、用户授权均为固定 Fixture；不代表真实生产权限。
- NLU 为可替换的规则实现；权限结论不由 LLM 计算。
- 不自动申请、审批或修改权限。
- 权限满足但仍无数据时，转人工，不猜业务数据或系统缺陷。

只维护四类高重建成本材料：

- `docs/decision-log.md`：append-only 决策日志
- `docs/assumption-ledger.md`：事实、假设、外部约束
- `docs/poc-proof.md`：待证明命题与退出标准
- `docs/experiment-log.md`：append-only 实验结果
